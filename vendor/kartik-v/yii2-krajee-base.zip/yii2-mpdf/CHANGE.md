version 1.0.0
=============
**Date:** 03-Nov-2014

- Initial release.
- Set release to stable.
