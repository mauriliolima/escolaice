version 1.3.0
=============
**Date:** 25-Nov-2014

- (enh #7): Enhance widget to use updated plugin registration from Krajee base 

version 1.2.0
=============
**Date:** 15-Nov-2014

- Set dependency on Krajee base components
- (enh #6): Validate right dependency with kartik\form\ActiveForm.
- Set release to stable

version 1.1.0
=============
** Date: 16-Sep-2014 **

- (enh #3): Upgrade field range jQuery plugin to work better with yii active form validation
- PSR4 alias change

version 1.0.0
=============
** Date: 14-Jul-2014 **

- Initial release